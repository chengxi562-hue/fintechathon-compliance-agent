"""构建平台提交用的源码压缩包（可复现、可审计）。

背景（2026-10-21）：
- 上一版 zip 是手工按文档里的内联脚本打的，没有对应的脚本文件——
  「成品由脚本生成、脚本必须入库」这条原则在这里断了。
- 上一版 zip 不含 data/evals/_metrics.json，导致评委解压后跑 pytest 得到
  「139 passed, 2 skipped」，而材料写的是「141 passed」——看起来像刷数，其实
  只是缺一份评测快照（该文件被 .gitignore 排除，运行 collect_metrics.py 才生成）。
  本脚本显式把它作为**快照**打进包，并在 README/打包说明里写清来源。

用法：
    PYTHONPATH=. .venv/bin/python scripts/package_submit.py
产物：
    submit/03_源代码与部署_v1.zip（根前缀 fintechathon/）
"""
from __future__ import annotations

import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "submit" / "03_源代码与部署_v1.zip"

# 目录级排除：环境、缓存、版本库、内部构建目录
SKIP_DIRS = {
    ".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", ".git", ".idea", ".vscode", ".refs", "_build", "_archive",
    "frames",  # 演示视频的中间帧 PNG，可由 render_demo_video.py 重生成
}
# 文件级排除：敏感文件、运行时产物、已交付成品
SKIP_NAMES = {".DS_Store", ".env", "_bench_latency.json"}
SKIP_SUFFIX = {".pyc", ".pyo", ".log"}
SKIP_SUBMIT_NAMES = {
    "01_技术文档_v1.docx", "01_项目说明书_v1.pdf",
    "02_答辩材料_v2.pptx", "03_源代码与部署_v1.zip",
    "04_安全自评报告_v1.docx", "05_演示视频_v0.mp4",
    # 内部操作文档：签字单/上传清单/字段草稿，不适合放进评委拿到的源码包
    "06_平台提交字段草稿_20261020.md",
    "07_高依灵_指标签字单_20261020.md",
    "08_上传操作清单_给本人_20261020.md",
}


def skip(rel: Path) -> bool:
    if any(p in SKIP_DIRS for p in rel.parts):
        return True
    if rel.name in SKIP_NAMES:
        return True
    if rel.suffix in SKIP_SUFFIX:
        return True
    if rel.name.startswith(".env.") and rel.name != ".env.example":
        return True
    if rel.suffix in {".zip", ".mp4", ".pptx", ".pdf", ".docx"} and "submit" in rel.parts:
        return True
    if "submit" in rel.parts and rel.name in SKIP_SUBMIT_NAMES:
        return True
    if rel.parts[:2] == ("data", "audit") and rel.name.endswith(".jsonl"):
        return True
    return False


def main() -> int:
    if not (ROOT / "data" / "evals" / "_metrics.json").exists():
        raise SystemExit(
            "缺少 data/evals/_metrics.json：先跑 scripts/collect_metrics.py，"
            "再把快照打进包（否则评委解压后测试会 skip 2 条）。"
        )
    files: list[Path] = []
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(ROOT)
        if skip(rel):
            continue
        files.append(rel)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for rel in files:
            zf.write(ROOT / rel, (Path("fintechathon") / rel).as_posix())
    size = OUT.stat().st_size
    print(f"wrote {OUT.relative_to(ROOT)}  files={len(files)}  size={size} bytes ({size/1024:.1f} KiB)")
    # 安全自检：包里不得出现敏感文件
    bad = [n for n in zipfile.ZipFile(OUT).namelist()
           if any(x in n.lower() for x in ("/.env", ".pem", "id_rsa")) and not n.endswith(".env.example")]
    if bad:
        raise SystemExit(f"包内发现敏感文件：{bad}")
    print("敏感文件自检：通过（无 .env/.pem/id_rsa）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
