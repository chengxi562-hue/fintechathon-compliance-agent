#!/usr/bin/env python3
"""上传前体检：一条命令核对五栏交付件是否「真的能交」。

为什么需要（2026-10-20/21 的教训）：
- 平台两栏停在旧版，靠肉眼看收据没发现；
- 源码包缺一份评测快照，解压后是 139 passed 而不是材料写的 141；
- 构建脚本输出路径错了，产物写到仓库根而不是 submit/。
这些都是「看起来成功」——本脚本把可机检的部分固定成检查项。

用法：
    python3 scripts/preflight_submit.py            # 快速体检（不跑测试）
    python3 scripts/preflight_submit.py --full     # 额外解压 + pytest（约 1 分钟）
退出码：0 全过；1 有 FAIL。
"""
from __future__ import annotations

import argparse
import hashlib
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SUB = ROOT / "submit"

# 平台五栏：文件名、上限 MB、期望最小体积（防呆：空文件/占位）
FILES = [
    ("01 技术文档", "01_项目说明书_v1.pdf", 50, 100_000),
    ("02 答辩材料", "02_答辩材料_v2.pptx", 80, 100_000),
    ("03 源代码", "03_源代码与部署_v1.zip", 300, 100_000),
    ("04 安全自评", "04_安全自评报告_v1.docx", 50, 20_000),
    ("05 演示视频", "05_演示视频_v0.mp4", 500, 500_000),
]

rows: list[tuple[str, str, str]] = []  # (项, 结果, 说明)


def add(item: str, ok: bool, note: str) -> None:
    rows.append((item, "PASS" if ok else "FAIL", note))


def pdf_pages(p: Path) -> int | None:
    """macOS 用 Quartz；没有就退回数 /Type /Page（可能不准，标注 *）。"""
    try:
        import Quartz, CoreFoundation  # type: ignore

        b = str(p).encode()
        url = CoreFoundation.CFURLCreateFromFileSystemRepresentation(None, b, len(b), False)
        doc = Quartz.PDFDocument.alloc().initWithURL_(url)
        return int(doc.pageCount())
    except Exception:
        raw = p.read_bytes()
        return len(re.findall(rb"/Type\s*/Page[^s]", raw)) or None


def pptx_slides(p: Path) -> int:
    with zipfile.ZipFile(p) as z:
        return len([n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)])


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--full", action="store_true", help="解压源码包并跑 pytest")
    args = ap.parse_args()

    for label, name, cap_mb, min_bytes in FILES:
        p = SUB / name
        if not p.exists():
            add(label, False, f"缺文件 {name}")
            continue
        size = p.stat().st_size
        h = hashlib.sha256(p.read_bytes()).hexdigest()[:12]
        ok = min_bytes <= size <= cap_mb * 1024 * 1024
        add(label, ok, f"{name} · {size/1024:.0f} KiB · sha256:{h} · 上限 {cap_mb} MB")

    pdf = SUB / "01_项目说明书_v1.pdf"
    if pdf.exists():
        n = pdf_pages(pdf)
        add("PDF 页数", n is not None and n >= 5, f"{n} 页")
    ppt = SUB / "02_答辩材料_v2.pptx"
    if ppt.exists():
        n = pptx_slides(ppt)
        add("PPT 页数", n >= 8, f"{n} 页")

    zp = SUB / "03_源代码与部署_v1.zip"
    if zp.exists():
        with zipfile.ZipFile(zp) as z:
            names = z.namelist()
            bad = [n for n in names if any(x in n.lower() for x in ("/.env", ".pem", "id_rsa", "/.venv/", "__pycache__"))
                   and not n.endswith(".env.example")]
            add("源码包清洁", not bad, f"{len(names)} 文件 · 敏感项 {bad[:3] or '0'}")
            add("评测快照在包内", any(n.endswith("data/evals/_metrics.json") for n in names),
                "缺它评委解压会看到 139 passed")
            add("内部操作文档未入包", not any(re.search(r"submit/(06|07|08)_", n) for n in names),
                "签字单/上传清单/字段草稿不进评委包")

    # 文档里的对外数字与快照一致（口径守卫的轻量版）
    metrics = ROOT / "data" / "evals" / "_metrics.json"
    if metrics.exists():
        import json

        m = json.loads(metrics.read_text(encoding="utf-8"))
        expect = str(m["pytest_total_passed"])
        claim = "141"
        add("单测数与快照一致", expect == claim, f"快照 {expect} / 材料 {claim}")

    if args.full and zp.exists():
        with tempfile.TemporaryDirectory() as td:
            with zipfile.ZipFile(zp) as z:
                z.extractall(td)
            testdir = Path(td) / "fintechathon"
            r = subprocess.run(
                [sys.executable, "-m", "pytest", "-q", "--tb=no"],
                cwd=testdir,
                capture_output=True,
                text=True,
                env={"PYTHONPATH": ".", "PATH": "/usr/bin:/bin:/usr/local/bin"},
                timeout=900,
            )
            tail = (r.stdout.strip().splitlines() or [""])[-1]
            add("解压即 pytest", r.returncode == 0, tail[:80])

    width = max(len(i) for i, _, _ in rows)
    print(f"{'检查项'.ljust(width)}  结果  说明")
    print("-" * (width + 40))
    for item, res, note in rows:
        print(f"{item.ljust(width)}  {res}  {note}")
    failed = [r for r in rows if r[1] == "FAIL"]
    print()
    if failed:
        print(f"FAIL {len(failed)} 项：先修再上传。")
        return 1
    print("全部通过：可以按 submit/08_上传操作清单 覆盖上传。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
