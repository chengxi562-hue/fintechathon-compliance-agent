# 交付件构建脚本

答辩 PPT / 技术文档 / 安全自评的生成源码。**这里是唯一真源**——成品由这些脚本生成，
脚本入库，任何人可重跑复现。

| 文件 | 产出 | 依赖 |
|---|---|---|
| `deck.js` | `submit/02_答辩材料_v2.pptx`（10 页） | `pptxgenjs` |
| `build_tech_doc.py` | `submit/01_技术文档_v1.docx` | `python-docx` |
| `build_security_report.py` | `submit/04_安全自评报告_v1.docx` | `python-docx` |

```bash
# 答辩 PPT
cd build_decks && NODE_PATH="$(npm root -g)" node deck.js

# 技术文档 / 安全自评（需先激活含 python-docx 的环境）
python build_decks/build_tech_doc.py
python build_decks/build_security_report.py

# 或一条命令：取数 → 注入 → 重建三件 → 导出 PDF → 守卫
bash scripts/refresh_all_metrics.sh
```

**字体注意**：deck.js 用 `Noto Sans CJK SC`，因为平台服务器渲染环境装的是这个字体。
本机（macOS）没有它，本地预览会掉字，但评委看到的是正确渲染。

## 2026-10-21 的两处修正

1. **输出路径**：两份 python 构建脚本原先写 `parents[1] / "01_技术文档_v1.docx"`，
   放在 `build_decks/` 下会把成品写到**仓库根**而不是 `submit/`。已改为显式拼 `submit/`。
2. **去重**：`submit/_build/` 曾保留一份完全相同的副本（被 .gitignore 排除），
   两份脚本一旦只改一份就会漂移；现已整目录归档到 `submit/_archive/_build_legacy_20261020/`，
   构建只认本目录。`scripts/sync_metrics.py` 与一致性守卫的目标路径也已同步改到这里。
